package com.masai.junit;

public class AppRunner {

	public static void main(String[] args) {
		//Calculator calculator = new Calculator();
		
		//System.out.println("Addition is -"+calculator.addIntegers(12, 23));

		//System.out.println("Multiplication is - "+calculator.multiply(12, 2));
	}

}
